﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class OrderVO
    {
        public int OrderID { get; set; }
        public DateTime RequiredDate { get; set; }
        public string CusID { get; set; }
        public string CusName { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime ReceiveDate { get; set; }
    }
}
