﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class BOMVO
    {
        public int BOMID { get; set; }
        public string ProdID { get; set; }
        public string MatID { get; set; }       
        public string PRNTMatCode { get; set; }        
        public int Quantity { get; set; }
        public string info { get; set; }
        public string ProdName { get; set; }
        public int Depth { get; set; }
        public int levels { get; set; }
        public string sortOrder { get; set; }

    }
}
