﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class OrderIncomeVO
    {
        public int IncomeID { get; set; }
        public int OrderDetailID { get; set; }
        public DateTime IncomeDate { get; set; }
        public int IncomeCount { get; set; }

        public int OrderID { get; set; }
        public string MaterialID { get; set; }
        public string MaterialName { get; set; }

        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int IncomeQuantity { get; set; }
        public string CusID { get; set; }
        public string CusName { get; set; }
        public DateTime RequiredDate { get; set; }
        public DateTime ReceiveDate { get; set; }


    }
}
