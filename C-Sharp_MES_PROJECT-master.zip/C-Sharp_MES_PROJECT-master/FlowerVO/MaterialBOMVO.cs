﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class MaterialBOMVO
    {
        public string  MaterialID { get; set; }
        public string MaterialName { get; set; }
        public int MaterialQuantity { get; set; }
        public int BOMID { get; set; }
        public string ProdID { get; set; }
        public string MatID { get; set; }
        public string MatCode { get; set; }
        public string PRNTMatCode { get; set; }
        public int Quantity { get; set; }
        
    }
}
