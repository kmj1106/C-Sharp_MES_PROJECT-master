﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class CustomerVO
    {
        public string CusID { get; set; }
        public string CusName { get; set; }
        public string Cuslicense { get; set; }
        public string CusManager { get; set; }
        public string CusCharge { get; set; }
        public string CusPhone { get; set; }
        public string CusEmail { get; set; }
    }
}
