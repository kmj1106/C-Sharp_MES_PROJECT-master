﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class CommonVO
    {
        public string CCode { get; set; }
        public string CName { get; set; }
        public string CCategory { get; set; }
    }
}
