﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class OrderDetailVO
    {
        public int OrderID { get; set; }
        public int OrderDetailID { get; set; }
        public string MaterialID { get; set; }
        public string MaterialName { get; set; }

        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
    }
}
