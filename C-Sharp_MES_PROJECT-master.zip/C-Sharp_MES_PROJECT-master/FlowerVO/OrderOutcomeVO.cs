﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlowerVO
{
    public class OrderOutcomeVO
    {
        public int OutcomeID { get; set; }
        public int IncomeID { get; set; }
        public DateTime OutcomeDate { get; set; }
        public int Quantity { get; set; }
        public string ProdID { get; set; }
        public int SaleDetailID { get; set; }

    }
}
