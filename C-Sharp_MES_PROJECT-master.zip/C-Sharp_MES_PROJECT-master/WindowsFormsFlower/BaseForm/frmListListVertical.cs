﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsFlower
{
    public partial class frmListListVertical : Form
    {
        public frmListListVertical()
        {
            InitializeComponent();
            //DataGridViewUtil.SetInitGridView(dataGridView1);
            //DataGridViewUtil.SetInitGridView(dataGridView2);
        }
    }
}
