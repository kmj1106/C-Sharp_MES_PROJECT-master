﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsFlower
{
    public partial class frmFlowerShopping : WindowsFormsFlower.BaseForm.frmTreeView
    {
        public frmFlowerShopping()
        {
            InitializeComponent();
        }
    }
}
