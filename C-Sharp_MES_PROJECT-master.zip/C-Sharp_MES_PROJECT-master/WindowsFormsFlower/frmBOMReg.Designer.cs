﻿
namespace WindowsFormsFlower
{
    partial class frmBOMReg
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.nmMatQuantity = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.btnItemDelete = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.txtProSearch = new System.Windows.Forms.TextBox();
            this.dgvBOMProduct = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductID = new System.Windows.Forms.Label();
            this.txtprodName = new System.Windows.Forms.TextBox();
            this.txtProdID = new System.Windows.Forms.TextBox();
            this.dgvBOMMatP = new System.Windows.Forms.DataGridView();
            this.btnItemSave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMatID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMatName = new System.Windows.Forms.TextBox();
            this.dgvBOMMat = new System.Windows.Forms.DataGridView();
            this.btnBomSave = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboType = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmMatQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMProduct)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMatP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMat)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.button2);
            this.splitContainer1.Size = new System.Drawing.Size(1329, 647);
            this.splitContainer1.SplitterDistance = 62;
            // 
            // splitContainer2
            // 
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvBOMProduct);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer2.Panel2.Controls.Add(this.btnBomSave);
            this.splitContainer2.Panel2.Controls.Add(this.dgvBOMMat);
            this.splitContainer2.Panel2.Controls.Add(this.dgvBOMMatP);
            this.splitContainer2.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer2.Size = new System.Drawing.Size(1329, 581);
            this.splitContainer2.SplitterDistance = 445;
            // 
            // splitContainer3
            // 
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.cboType);
            this.splitContainer3.Panel2.Controls.Add(this.button4);
            this.splitContainer3.Panel2.Controls.Add(this.txtProSearch);
            this.splitContainer3.Size = new System.Drawing.Size(1329, 62);
            this.splitContainer3.SplitterDistance = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(-190, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = "제품코드";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1099, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 21);
            this.button2.TabIndex = 12;
            this.button2.Text = "복사";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // nmMatQuantity
            // 
            this.nmMatQuantity.Location = new System.Drawing.Point(79, 100);
            this.nmMatQuantity.Name = "nmMatQuantity";
            this.nmMatQuantity.Size = new System.Drawing.Size(120, 21);
            this.nmMatQuantity.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 52;
            this.label8.Text = "수량";
            // 
            // btnItemDelete
            // 
            this.btnItemDelete.Location = new System.Drawing.Point(258, 125);
            this.btnItemDelete.Name = "btnItemDelete";
            this.btnItemDelete.Size = new System.Drawing.Size(95, 30);
            this.btnItemDelete.TabIndex = 57;
            this.btnItemDelete.Text = "Item 삭제";
            this.btnItemDelete.UseVisualStyleBackColor = true;
            this.btnItemDelete.Click += new System.EventHandler(this.btnItemDelete_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(179, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 18;
            this.button4.Text = "검색";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtProSearch
            // 
            this.txtProSearch.Location = new System.Drawing.Point(28, 5);
            this.txtProSearch.Name = "txtProSearch";
            this.txtProSearch.Size = new System.Drawing.Size(145, 21);
            this.txtProSearch.TabIndex = 17;
            // 
            // dgvBOMProduct
            // 
            this.dgvBOMProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBOMProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBOMProduct.Location = new System.Drawing.Point(0, 0);
            this.dgvBOMProduct.Name = "dgvBOMProduct";
            this.dgvBOMProduct.RowTemplate.Height = 23;
            this.dgvBOMProduct.Size = new System.Drawing.Size(445, 581);
            this.dgvBOMProduct.TabIndex = 0;
            this.dgvBOMProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBOMProduct_CellDoubleClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblProductName);
            this.groupBox1.Controls.Add(this.lblProductID);
            this.groupBox1.Controls.Add(this.txtprodName);
            this.groupBox1.Controls.Add(this.txtProdID);
            this.groupBox1.Location = new System.Drawing.Point(37, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(359, 87);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "완제품정보";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(24, 59);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(41, 12);
            this.lblProductName.TabIndex = 3;
            this.lblProductName.Text = "제품명";
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(24, 23);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(40, 12);
            this.lblProductID.TabIndex = 2;
            this.lblProductID.Text = "제품ID";
            // 
            // txtprodName
            // 
            this.txtprodName.Location = new System.Drawing.Point(68, 56);
            this.txtprodName.Name = "txtprodName";
            this.txtprodName.Size = new System.Drawing.Size(234, 21);
            this.txtprodName.TabIndex = 1;
            // 
            // txtProdID
            // 
            this.txtProdID.Location = new System.Drawing.Point(68, 20);
            this.txtProdID.Name = "txtProdID";
            this.txtProdID.Size = new System.Drawing.Size(234, 21);
            this.txtProdID.TabIndex = 0;
            // 
            // dgvBOMMatP
            // 
            this.dgvBOMMatP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBOMMatP.Location = new System.Drawing.Point(39, 191);
            this.dgvBOMMatP.Name = "dgvBOMMatP";
            this.dgvBOMMatP.RowTemplate.Height = 23;
            this.dgvBOMMatP.Size = new System.Drawing.Size(356, 377);
            this.dgvBOMMatP.TabIndex = 59;
            // 
            // btnItemSave
            // 
            this.btnItemSave.Location = new System.Drawing.Point(157, 125);
            this.btnItemSave.Name = "btnItemSave";
            this.btnItemSave.Size = new System.Drawing.Size(95, 30);
            this.btnItemSave.TabIndex = 60;
            this.btnItemSave.Text = "Item저장";
            this.btnItemSave.UseVisualStyleBackColor = true;
            this.btnItemSave.Click += new System.EventHandler(this.btnItemSave_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 42;
            this.label3.Text = "품목코드";
            // 
            // txtMatID
            // 
            this.txtMatID.Location = new System.Drawing.Point(79, 21);
            this.txtMatID.Name = "txtMatID";
            this.txtMatID.Size = new System.Drawing.Size(200, 21);
            this.txtMatID.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 46;
            this.label4.Text = "품명";
            // 
            // txtMatName
            // 
            this.txtMatName.Location = new System.Drawing.Point(79, 60);
            this.txtMatName.Name = "txtMatName";
            this.txtMatName.Size = new System.Drawing.Size(200, 21);
            this.txtMatName.TabIndex = 47;
            // 
            // dgvBOMMat
            // 
            this.dgvBOMMat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBOMMat.Location = new System.Drawing.Point(479, 191);
            this.dgvBOMMat.Name = "dgvBOMMat";
            this.dgvBOMMat.RowTemplate.Height = 23;
            this.dgvBOMMat.Size = new System.Drawing.Size(364, 377);
            this.dgvBOMMat.TabIndex = 61;
            this.dgvBOMMat.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBOMMat_CellDoubleClick);
            // 
            // btnBomSave
            // 
            this.btnBomSave.Location = new System.Drawing.Point(303, 140);
            this.btnBomSave.Name = "btnBomSave";
            this.btnBomSave.Size = new System.Drawing.Size(92, 32);
            this.btnBomSave.TabIndex = 62;
            this.btnBomSave.Text = "BOM저장";
            this.btnBomSave.UseVisualStyleBackColor = true;
            this.btnBomSave.Click += new System.EventHandler(this.btnBomSave_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMatID);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtMatName);
            this.groupBox2.Controls.Add(this.btnItemSave);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.btnItemDelete);
            this.groupBox2.Controls.Add(this.nmMatQuantity);
            this.groupBox2.Location = new System.Drawing.Point(479, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(359, 161);
            this.groupBox2.TabIndex = 64;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "제품정보";
            // 
            // cboType
            // 
            this.cboType.FormattingEnabled = true;
            this.cboType.Items.AddRange(new object[] {
            "선택",
            "완제품",
            "반제품"});
            this.cboType.Location = new System.Drawing.Point(260, 5);
            this.cboType.Name = "cboType";
            this.cboType.Size = new System.Drawing.Size(77, 20);
            this.cboType.TabIndex = 19;
            this.cboType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // frmBOMReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.ClientSize = new System.Drawing.Size(1329, 647);
            this.Name = "frmBOMReg";
            this.Text = "BOM 등록";
            this.Load += new System.EventHandler(this.frmBOMReg_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmMatQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMProduct)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMatP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMat)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown nmMatQuantity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnItemDelete;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox txtProSearch;
        private System.Windows.Forms.DataGridView dgvBOMProduct;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMatID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMatName;
        private System.Windows.Forms.Button btnItemSave;
        private System.Windows.Forms.Button btnBomSave;
        private System.Windows.Forms.DataGridView dgvBOMMat;
        private System.Windows.Forms.DataGridView dgvBOMMatP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtprodName;
        private System.Windows.Forms.TextBox txtProdID;
        private System.Windows.Forms.ComboBox cboType;
    }
}
