﻿
namespace WindowsFormsFlower
{
    partial class frmMyPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cboGender = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpUserBirth = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUserPwd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUserPhone = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUserEmail2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUserEmail1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.zipControl1 = new WindowsFormsFlower.ZipControl();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReserveCancel = new System.Windows.Forms.Button();
            this.dgvReserve = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReserve)).BeginInit();
            this.SuspendLayout();
            // 
            // cboGender
            // 
            this.cboGender.FormattingEnabled = true;
            this.cboGender.Items.AddRange(new object[] {
            "남",
            "여"});
            this.cboGender.Location = new System.Drawing.Point(559, 68);
            this.cboGender.Name = "cboGender";
            this.cboGender.Size = new System.Drawing.Size(57, 23);
            this.cboGender.TabIndex = 59;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(470, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 15);
            this.label9.TabIndex = 58;
            this.label9.Text = "생년월일";
            // 
            // dtpUserBirth
            // 
            this.dtpUserBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpUserBirth.Location = new System.Drawing.Point(559, 28);
            this.dtpUserBirth.Name = "dtpUserBirth";
            this.dtpUserBirth.Size = new System.Drawing.Size(100, 21);
            this.dtpUserBirth.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(470, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 15);
            this.label8.TabIndex = 56;
            this.label8.Text = "성별";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(113, 73);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(100, 21);
            this.txtUserName.TabIndex = 55;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 15);
            this.label6.TabIndex = 54;
            this.label6.Text = "이름";
            // 
            // txtUserPwd
            // 
            this.txtUserPwd.Location = new System.Drawing.Point(114, 117);
            this.txtUserPwd.Name = "txtUserPwd";
            this.txtUserPwd.Size = new System.Drawing.Size(100, 21);
            this.txtUserPwd.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 50;
            this.label4.Text = "비밀번호";
            // 
            // txtUserPhone
            // 
            this.txtUserPhone.Location = new System.Drawing.Point(559, 110);
            this.txtUserPhone.Mask = "000-9000-0000";
            this.txtUserPhone.Name = "txtUserPhone";
            this.txtUserPhone.Size = new System.Drawing.Size(100, 21);
            this.txtUserPhone.TabIndex = 48;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(470, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 15);
            this.label7.TabIndex = 49;
            this.label7.Text = "전화번호";
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(113, 30);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.ReadOnly = true;
            this.txtUserID.Size = new System.Drawing.Size(100, 21);
            this.txtUserID.TabIndex = 46;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 45;
            this.label3.Text = "회원ID";
            // 
            // txtUserEmail2
            // 
            this.txtUserEmail2.Location = new System.Drawing.Point(231, 280);
            this.txtUserEmail2.Name = "txtUserEmail2";
            this.txtUserEmail2.Size = new System.Drawing.Size(100, 21);
            this.txtUserEmail2.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(213, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 15);
            this.label2.TabIndex = 42;
            this.label2.Text = "@";
            // 
            // txtUserEmail1
            // 
            this.txtUserEmail1.Location = new System.Drawing.Point(113, 280);
            this.txtUserEmail1.Name = "txtUserEmail1";
            this.txtUserEmail1.Size = new System.Drawing.Size(100, 21);
            this.txtUserEmail1.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 284);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 40;
            this.label1.Text = "이메일";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.zipControl1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.cboGender);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.dtpUserBirth);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtUserName);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtUserPwd);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtUserPhone);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtUserID);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtUserEmail2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtUserEmail1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel1.Location = new System.Drawing.Point(22, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(791, 333);
            this.panel1.TabIndex = 60;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 15);
            this.label5.TabIndex = 62;
            this.label5.Text = "주소";
            // 
            // zipControl1
            // 
            this.zipControl1.Address1 = "";
            this.zipControl1.Address2 = "";
            this.zipControl1.Location = new System.Drawing.Point(111, 163);
            this.zipControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.zipControl1.Name = "zipControl1";
            this.zipControl1.Size = new System.Drawing.Size(329, 102);
            this.zipControl1.TabIndex = 61;
            this.zipControl1.ZipCode = "";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(695, 284);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 34);
            this.button3.TabIndex = 60;
            this.button3.Text = "수정하기";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel2.Location = new System.Drawing.Point(22, 381);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(791, 250);
            this.panel2.TabIndex = 61;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnReserveCancel);
            this.groupBox1.Controls.Add(this.dgvReserve);
            this.groupBox1.Location = new System.Drawing.Point(25, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(752, 232);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "주문내역";
            // 
            // btnReserveCancel
            // 
            this.btnReserveCancel.Location = new System.Drawing.Point(664, 201);
            this.btnReserveCancel.Name = "btnReserveCancel";
            this.btnReserveCancel.Size = new System.Drawing.Size(82, 25);
            this.btnReserveCancel.TabIndex = 1;
            this.btnReserveCancel.Text = "주문취소";
            this.btnReserveCancel.UseVisualStyleBackColor = true;
            this.btnReserveCancel.Click += new System.EventHandler(this.btnReserveCancel_Click);
            // 
            // dgvReserve
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReserve.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvReserve.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReserve.Location = new System.Drawing.Point(19, 20);
            this.dgvReserve.Name = "dgvReserve";
            this.dgvReserve.RowTemplate.Height = 23;
            this.dgvReserve.Size = new System.Drawing.Size(642, 177);
            this.dgvReserve.TabIndex = 0;
            // 
            // frmMyPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(835, 643);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Name = "frmMyPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "마이페이지";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMyPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReserve)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox cboGender;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpUserBirth;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtUserPwd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox txtUserPhone;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUserEmail2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUserEmail1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReserveCancel;
        private System.Windows.Forms.DataGridView dgvReserve;
        private ZipControl zipControl1;
        private System.Windows.Forms.Label label5;
    }
}