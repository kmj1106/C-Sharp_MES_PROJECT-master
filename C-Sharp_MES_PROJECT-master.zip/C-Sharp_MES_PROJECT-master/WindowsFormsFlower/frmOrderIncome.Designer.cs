﻿
namespace WindowsFormsFlower
{
    partial class frmOrderIncome
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.rboIn = new System.Windows.Forms.RadioButton();
            this.rboNotin = new System.Windows.Forms.RadioButton();
            this.dgvIncome = new System.Windows.Forms.DataGridView();
            this.dgvIncomeDetail = new System.Windows.Forms.DataGridView();
            this.periodUserControl1 = new WindowsFormsFlower.PeriodUserControl();
            this.label23 = new System.Windows.Forms.Label();
            this.cboMaterial = new System.Windows.Forms.ComboBox();
            this.cboCustomer = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnCheck = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.nuQuantity = new System.Windows.Forms.NumericUpDown();
            this.rboAll = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIncome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIncomeDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(919, 77);
            // 
            // splitContainer4
            // 
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.dgvIncomeDetail);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.nuQuantity);
            this.splitContainer4.Panel2.Controls.Add(this.label2);
            this.splitContainer4.Panel2.Controls.Add(this.btnCheck);
            this.splitContainer4.Size = new System.Drawing.Size(919, 207);
            this.splitContainer4.SplitterDistance = 172;
            // 
            // splitContainer2
            // 
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvIncome);
            this.splitContainer2.Size = new System.Drawing.Size(919, 485);
            this.splitContainer2.SplitterDistance = 235;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.Text = "상세 내역";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Size = new System.Drawing.Size(919, 246);
            this.splitContainer1.SplitterDistance = 35;
            // 
            // splitContainer3
            // 
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.rboAll);
            this.splitContainer3.Panel2.Controls.Add(this.label23);
            this.splitContainer3.Panel2.Controls.Add(this.cboCustomer);
            this.splitContainer3.Panel2.Controls.Add(this.label20);
            this.splitContainer3.Panel2.Controls.Add(this.cboMaterial);
            this.splitContainer3.Panel2.Controls.Add(this.periodUserControl1);
            this.splitContainer3.Panel2.Controls.Add(this.btnSearch);
            this.splitContainer3.Panel2.Controls.Add(this.rboIn);
            this.splitContainer3.Panel2.Controls.Add(this.rboNotin);
            this.splitContainer3.Size = new System.Drawing.Size(919, 77);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(605, 8);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(77, 21);
            this.btnSearch.TabIndex = 22;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "입고관리";
            // 
            // rboIn
            // 
            this.rboIn.AutoSize = true;
            this.rboIn.Location = new System.Drawing.Point(834, 10);
            this.rboIn.Name = "rboIn";
            this.rboIn.Size = new System.Drawing.Size(71, 16);
            this.rboIn.TabIndex = 19;
            this.rboIn.TabStop = true;
            this.rboIn.Text = "입고완료";
            this.rboIn.UseVisualStyleBackColor = true;
            // 
            // rboNotin
            // 
            this.rboNotin.AutoSize = true;
            this.rboNotin.Location = new System.Drawing.Point(768, 10);
            this.rboNotin.Name = "rboNotin";
            this.rboNotin.Size = new System.Drawing.Size(59, 16);
            this.rboNotin.TabIndex = 18;
            this.rboNotin.TabStop = true;
            this.rboNotin.Text = "미입고";
            this.rboNotin.UseVisualStyleBackColor = true;
            // 
            // dgvIncome
            // 
            this.dgvIncome.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIncome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvIncome.Location = new System.Drawing.Point(0, 0);
            this.dgvIncome.Name = "dgvIncome";
            this.dgvIncome.RowTemplate.Height = 23;
            this.dgvIncome.Size = new System.Drawing.Size(919, 235);
            this.dgvIncome.TabIndex = 0;
            this.dgvIncome.Tag = "dgvIncome";
            this.dgvIncome.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvIncome_CellDoubleClick);
            // 
            // dgvIncomeDetail
            // 
            this.dgvIncomeDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIncomeDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvIncomeDetail.Location = new System.Drawing.Point(0, 0);
            this.dgvIncomeDetail.Name = "dgvIncomeDetail";
            this.dgvIncomeDetail.RowTemplate.Height = 23;
            this.dgvIncomeDetail.Size = new System.Drawing.Size(919, 172);
            this.dgvIncomeDetail.TabIndex = 0;
            this.dgvIncomeDetail.Tag = "dgvIncomeDetail";
            // 
            // periodUserControl1
            // 
            this.periodUserControl1.Location = new System.Drawing.Point(313, 6);
            this.periodUserControl1.Name = "periodUserControl1";
            this.periodUserControl1.Size = new System.Drawing.Size(287, 24);
            this.periodUserControl1.TabIndex = 24;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(177, 12);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 46;
            this.label23.Text = "재료명";
            // 
            // cboMaterial
            // 
            this.cboMaterial.FormattingEnabled = true;
            this.cboMaterial.Location = new System.Drawing.Point(230, 8);
            this.cboMaterial.Name = "cboMaterial";
            this.cboMaterial.Size = new System.Drawing.Size(73, 20);
            this.cboMaterial.TabIndex = 45;
            this.cboMaterial.SelectedIndexChanged += new System.EventHandler(this.cboMaterial_SelectedIndexChanged);
            // 
            // cboCustomer
            // 
            this.cboCustomer.FormattingEnabled = true;
            this.cboCustomer.Location = new System.Drawing.Point(80, 8);
            this.cboCustomer.Name = "cboCustomer";
            this.cboCustomer.Size = new System.Drawing.Size(86, 20);
            this.cboCustomer.TabIndex = 44;
            this.cboCustomer.SelectedIndexChanged += new System.EventHandler(this.cboCustomer_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 43;
            this.label20.Text = "거래처명";
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(813, 5);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(75, 23);
            this.btnCheck.TabIndex = 0;
            this.btnCheck.Text = "입고처리";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(662, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "입고수량";
            // 
            // nuQuantity
            // 
            this.nuQuantity.Location = new System.Drawing.Point(737, 5);
            this.nuQuantity.Name = "nuQuantity";
            this.nuQuantity.Size = new System.Drawing.Size(59, 21);
            this.nuQuantity.TabIndex = 3;
            this.nuQuantity.ValueChanged += new System.EventHandler(this.nuQuantity_ValueChanged);
            // 
            // rboAll
            // 
            this.rboAll.AutoSize = true;
            this.rboAll.Location = new System.Drawing.Point(692, 10);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new System.Drawing.Size(71, 16);
            this.rboAll.TabIndex = 47;
            this.rboAll.TabStop = true;
            this.rboAll.Text = "전체내역";
            this.rboAll.UseVisualStyleBackColor = true;
            // 
            // frmOrderIncome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.ClientSize = new System.Drawing.Size(919, 562);
            this.Name = "frmOrderIncome";
            this.Text = "입고관리";
            this.Load += new System.EventHandler(this.frmOrderIncome_Load);
            this.panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvIncome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIncomeDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuQuantity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        protected System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rboIn;
        private System.Windows.Forms.RadioButton rboNotin;
        private System.Windows.Forms.DataGridView dgvIncomeDetail;
        private System.Windows.Forms.DataGridView dgvIncome;
        private PeriodUserControl periodUserControl1;
        protected System.Windows.Forms.Label label23;
        protected System.Windows.Forms.ComboBox cboCustomer;
        protected System.Windows.Forms.Label label20;
        protected System.Windows.Forms.ComboBox cboMaterial;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nuQuantity;
        private System.Windows.Forms.RadioButton rboAll;
    }
}
