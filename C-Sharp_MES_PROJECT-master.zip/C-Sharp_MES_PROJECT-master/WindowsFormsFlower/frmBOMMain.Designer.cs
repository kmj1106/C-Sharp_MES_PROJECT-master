﻿
namespace WindowsFormsFlower
{
    partial class frmBOMMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBOMSearch = new System.Windows.Forms.Button();
            this.txtBOMName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboBOMType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvBOMMain = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMain)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnBOMSearch);
            this.panel1.Controls.Add(this.txtBOMName);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cboBOMType);
            this.panel1.Controls.Add(this.label1);
            // 
            // splitContainer1
            // 
            // 
            // splitContainer2
            // 
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dgvBOMMain);
            // 
            // btnBOMSearch
            // 
            this.btnBOMSearch.Location = new System.Drawing.Point(744, 6);
            this.btnBOMSearch.Name = "btnBOMSearch";
            this.btnBOMSearch.Size = new System.Drawing.Size(94, 20);
            this.btnBOMSearch.TabIndex = 20;
            this.btnBOMSearch.Text = "검색";
            this.btnBOMSearch.UseVisualStyleBackColor = true;
            this.btnBOMSearch.Click += new System.EventHandler(this.btnBOMSearch_Click);
            // 
            // txtBOMName
            // 
            this.txtBOMName.Location = new System.Drawing.Point(581, 4);
            this.txtBOMName.Name = "txtBOMName";
            this.txtBOMName.Size = new System.Drawing.Size(146, 21);
            this.txtBOMName.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(534, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 18;
            this.label2.Text = "품목명";
            // 
            // cboBOMType
            // 
            this.cboBOMType.FormattingEnabled = true;
            this.cboBOMType.Location = new System.Drawing.Point(56, 6);
            this.cboBOMType.Name = "cboBOMType";
            this.cboBOMType.Size = new System.Drawing.Size(121, 20);
            this.cboBOMType.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 16;
            this.label1.Text = "유형";
            // 
            // dgvBOMMain
            // 
            this.dgvBOMMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBOMMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBOMMain.Location = new System.Drawing.Point(0, 0);
            this.dgvBOMMain.Name = "dgvBOMMain";
            this.dgvBOMMain.RowTemplate.Height = 23;
            this.dgvBOMMain.Size = new System.Drawing.Size(845, 453);
            this.dgvBOMMain.TabIndex = 0;
            // 
            // frmBOMMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.ClientSize = new System.Drawing.Size(845, 518);
            this.Name = "frmBOMMain";
            this.Text = "BOM 메인";
            this.Load += new System.EventHandler(this.frmBOMMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBOMSearch;
        private System.Windows.Forms.TextBox txtBOMName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboBOMType;
        private System.Windows.Forms.Label label1;
        protected System.Windows.Forms.DataGridView dgvBOMMain;
    }
}
