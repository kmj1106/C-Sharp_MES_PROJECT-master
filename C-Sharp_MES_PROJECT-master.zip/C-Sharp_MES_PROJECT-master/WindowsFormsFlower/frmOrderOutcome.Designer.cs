﻿
namespace WindowsFormsFlower
{
    partial class frmOrderOutcome
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnEndSearch = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.lbl = new System.Windows.Forms.Label();
            this.dgvWating = new System.Windows.Forms.DataGridView();
            this.dgvOutcome = new System.Windows.Forms.DataGridView();
            this.periodUserControl1 = new WindowsFormsFlower.PeriodUserControl();
            this.periodUserControl2 = new WindowsFormsFlower.PeriodUserControl();
            this.button2 = new System.Windows.Forms.Button();
            this.btnWaitSearch = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWating)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutcome)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(965, 77);
            // 
            // splitContainer4
            // 
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.dgvOutcome);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.btnCheck);
            this.splitContainer4.Size = new System.Drawing.Size(965, 229);
            this.splitContainer4.SplitterDistance = 187;
            // 
            // splitContainer2
            // 
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvWating);
            this.splitContainer2.Size = new System.Drawing.Size(965, 486);
            this.splitContainer2.SplitterDistance = 214;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(27, 12);
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.Text = "출고 완료 내역";
            // 
            // splitContainer1
            // 
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.periodUserControl1);
            this.splitContainer1.Panel1.Controls.Add(this.button4);
            this.splitContainer1.Panel1.Controls.Add(this.btnEndSearch);
            this.splitContainer1.Size = new System.Drawing.Size(965, 268);
            this.splitContainer1.SplitterDistance = 35;
            // 
            // splitContainer3
            // 
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.lbl);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.periodUserControl2);
            this.splitContainer3.Panel2.Controls.Add(this.button2);
            this.splitContainer3.Panel2.Controls.Add(this.label3);
            this.splitContainer3.Panel2.Controls.Add(this.btnWaitSearch);
            this.splitContainer3.Size = new System.Drawing.Size(965, 77);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(514, 8);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(77, 21);
            this.button4.TabIndex = 16;
            this.button4.Text = "전체내역";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "출고 대기 내역";
            // 
            // btnEndSearch
            // 
            this.btnEndSearch.Location = new System.Drawing.Point(413, 8);
            this.btnEndSearch.Name = "btnEndSearch";
            this.btnEndSearch.Size = new System.Drawing.Size(77, 21);
            this.btnEndSearch.TabIndex = 11;
            this.btnEndSearch.Text = "검색";
            this.btnEndSearch.UseVisualStyleBackColor = true;
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(855, 7);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(75, 23);
            this.btnCheck.TabIndex = 1;
            this.btnCheck.Text = "출고처리";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(27, 12);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(53, 12);
            this.lbl.TabIndex = 0;
            this.lbl.Text = "출고관리";
            // 
            // dgvWating
            // 
            this.dgvWating.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWating.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvWating.Location = new System.Drawing.Point(0, 0);
            this.dgvWating.Name = "dgvWating";
            this.dgvWating.RowTemplate.Height = 23;
            this.dgvWating.Size = new System.Drawing.Size(965, 214);
            this.dgvWating.TabIndex = 1;
            // 
            // dgvOutcome
            // 
            this.dgvOutcome.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOutcome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOutcome.Location = new System.Drawing.Point(0, 0);
            this.dgvOutcome.Name = "dgvOutcome";
            this.dgvOutcome.RowTemplate.Height = 23;
            this.dgvOutcome.Size = new System.Drawing.Size(965, 187);
            this.dgvOutcome.TabIndex = 0;
            this.dgvOutcome.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOutcomeDetail_CellDoubleClick);
            // 
            // periodUserControl1
            // 
            this.periodUserControl1.Location = new System.Drawing.Point(120, 7);
            this.periodUserControl1.Name = "periodUserControl1";
            this.periodUserControl1.Size = new System.Drawing.Size(287, 24);
            this.periodUserControl1.TabIndex = 18;
            // 
            // periodUserControl2
            // 
            this.periodUserControl2.Location = new System.Drawing.Point(118, 7);
            this.periodUserControl2.Name = "periodUserControl2";
            this.periodUserControl2.Size = new System.Drawing.Size(287, 24);
            this.periodUserControl2.TabIndex = 21;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(512, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(77, 21);
            this.button2.TabIndex = 20;
            this.button2.Text = "전체내역";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnWaitSearch
            // 
            this.btnWaitSearch.Location = new System.Drawing.Point(414, 8);
            this.btnWaitSearch.Name = "btnWaitSearch";
            this.btnWaitSearch.Size = new System.Drawing.Size(77, 21);
            this.btnWaitSearch.TabIndex = 19;
            this.btnWaitSearch.Text = "검색";
            this.btnWaitSearch.UseVisualStyleBackColor = true;
            this.btnWaitSearch.Click += new System.EventHandler(this.btnWaitSearch_Click);
            // 
            // frmOrderOutcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.ClientSize = new System.Drawing.Size(965, 563);
            this.Name = "frmOrderOutcome";
            this.Text = "출고관리";
            this.Load += new System.EventHandler(this.frmOrderOutcome_Load);
            this.panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvWating)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutcome)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        protected System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        protected System.Windows.Forms.Button btnEndSearch;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.DataGridView dgvWating;
        private System.Windows.Forms.DataGridView dgvOutcome;
        private PeriodUserControl periodUserControl1;
        private PeriodUserControl periodUserControl2;
        protected System.Windows.Forms.Button button2;
        protected System.Windows.Forms.Button btnWaitSearch;
    }
}
