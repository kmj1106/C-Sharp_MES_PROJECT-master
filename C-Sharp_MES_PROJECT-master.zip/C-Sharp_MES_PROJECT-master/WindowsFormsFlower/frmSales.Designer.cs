﻿
namespace WindowsFormsFlower
{
    partial class frmSales
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.rboWaiting = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.rboEnd = new System.Windows.Forms.RadioButton();
            this.rboReady = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvSale = new System.Windows.Forms.DataGridView();
            this.dgvSaleDetail = new System.Windows.Forms.DataGridView();
            this.rboAll = new System.Windows.Forms.RadioButton();
            this.periodUserControl1 = new WindowsFormsFlower.PeriodUserControl();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaleDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(924, 77);
            // 
            // splitContainer4
            // 
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.dgvSaleDetail);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.btnCancel);
            this.splitContainer4.Panel2.Controls.Add(this.btnOk);
            this.splitContainer4.Size = new System.Drawing.Size(924, 225);
            this.splitContainer4.SplitterDistance = 187;
            // 
            // splitContainer2
            // 
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvSale);
            this.splitContainer2.Size = new System.Drawing.Size(924, 478);
            this.splitContainer2.SplitterDistance = 210;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(30, 12);
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.Text = "상세내역";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Size = new System.Drawing.Size(924, 264);
            this.splitContainer1.SplitterDistance = 35;
            // 
            // splitContainer3
            // 
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.label4);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.periodUserControl1);
            this.splitContainer3.Panel2.Controls.Add(this.rboAll);
            this.splitContainer3.Panel2.Controls.Add(this.rboWaiting);
            this.splitContainer3.Panel2.Controls.Add(this.label3);
            this.splitContainer3.Panel2.Controls.Add(this.rboEnd);
            this.splitContainer3.Panel2.Controls.Add(this.rboReady);
            this.splitContainer3.Panel2.Controls.Add(this.btnSearch);
            this.splitContainer3.Size = new System.Drawing.Size(924, 77);
            // 
            // rboWaiting
            // 
            this.rboWaiting.AutoSize = true;
            this.rboWaiting.Location = new System.Drawing.Point(573, 12);
            this.rboWaiting.Name = "rboWaiting";
            this.rboWaiting.Size = new System.Drawing.Size(71, 16);
            this.rboWaiting.TabIndex = 18;
            this.rboWaiting.TabStop = true;
            this.rboWaiting.Tag = "주문대기";
            this.rboWaiting.Text = "주문대기";
            this.rboWaiting.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "판매내역";
            // 
            // rboEnd
            // 
            this.rboEnd.AutoSize = true;
            this.rboEnd.Location = new System.Drawing.Point(729, 12);
            this.rboEnd.Name = "rboEnd";
            this.rboEnd.Size = new System.Drawing.Size(71, 16);
            this.rboEnd.TabIndex = 14;
            this.rboEnd.TabStop = true;
            this.rboEnd.Tag = "판매완료";
            this.rboEnd.Text = "판매완료";
            this.rboEnd.UseVisualStyleBackColor = true;
            // 
            // rboReady
            // 
            this.rboReady.AutoSize = true;
            this.rboReady.Location = new System.Drawing.Point(655, 12);
            this.rboReady.Name = "rboReady";
            this.rboReady.Size = new System.Drawing.Size(59, 16);
            this.rboReady.TabIndex = 13;
            this.rboReady.TabStop = true;
            this.rboReady.Tag = "준비중";
            this.rboReady.Text = "준비중";
            this.rboReady.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(391, 9);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(77, 21);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "검색";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(831, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "주문취소";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(749, 7);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "주문수락";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "판매관리";
            // 
            // dgvSale
            // 
            this.dgvSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSale.Location = new System.Drawing.Point(0, 0);
            this.dgvSale.Name = "dgvSale";
            this.dgvSale.RowTemplate.Height = 23;
            this.dgvSale.Size = new System.Drawing.Size(924, 210);
            this.dgvSale.TabIndex = 0;
            this.dgvSale.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSale_CellDoubleClick);
            // 
            // dgvSaleDetail
            // 
            this.dgvSaleDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSaleDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSaleDetail.Location = new System.Drawing.Point(0, 0);
            this.dgvSaleDetail.Name = "dgvSaleDetail";
            this.dgvSaleDetail.RowTemplate.Height = 23;
            this.dgvSaleDetail.Size = new System.Drawing.Size(924, 187);
            this.dgvSaleDetail.TabIndex = 0;
            // 
            // rboAll
            // 
            this.rboAll.AutoSize = true;
            this.rboAll.Location = new System.Drawing.Point(496, 12);
            this.rboAll.Name = "rboAll";
            this.rboAll.Size = new System.Drawing.Size(71, 16);
            this.rboAll.TabIndex = 20;
            this.rboAll.TabStop = true;
            this.rboAll.Tag = "전체내역";
            this.rboAll.Text = "전체내역";
            this.rboAll.UseVisualStyleBackColor = true;
            // 
            // periodUserControl1
            // 
            this.periodUserControl1.Location = new System.Drawing.Point(90, 8);
            this.periodUserControl1.Name = "periodUserControl1";
            this.periodUserControl1.Size = new System.Drawing.Size(287, 24);
            this.periodUserControl1.TabIndex = 21;
            // 
            // frmSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.ClientSize = new System.Drawing.Size(924, 555);
            this.Name = "frmSales";
            this.Text = "판매관리";
            this.Load += new System.EventHandler(this.frmSales_Load);
            this.panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaleDetail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RadioButton rboWaiting;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rboEnd;
        private System.Windows.Forms.RadioButton rboReady;
        protected System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvSaleDetail;
        private System.Windows.Forms.DataGridView dgvSale;
        private System.Windows.Forms.RadioButton rboAll;
        private PeriodUserControl periodUserControl1;
    }
}
